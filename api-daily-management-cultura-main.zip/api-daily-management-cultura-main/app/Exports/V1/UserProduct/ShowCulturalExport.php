<?php

namespace App\Exports\V1\UserProduct;

use Maatwebsite\Excel\Concerns\FromCollection;

class ShowCulturalExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
