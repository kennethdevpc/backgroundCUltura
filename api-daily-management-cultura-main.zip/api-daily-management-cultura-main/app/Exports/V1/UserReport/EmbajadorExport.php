<?php

namespace App\Exports\V1\UserReport;

use Maatwebsite\Excel\Concerns\FromCollection;

class EmbajadorExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
