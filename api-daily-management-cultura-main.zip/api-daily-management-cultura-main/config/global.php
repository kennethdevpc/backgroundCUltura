<?php

return [
  'limitSheet' => 25,
  'paginate'=>100
]

?>
