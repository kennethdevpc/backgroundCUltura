<?php

return [
    'super_root' => 1,
    'root' => 2,
    'apoyo_metodologico' => 3,
    'apoyo_al_seguimiento_monitoreo' => 4,
    'coordinador_metodologico' => 5,
    'subdireccion' => 6,
    'direccion' => 7,
    'psicosocial' => 8,
    'coordinador_psicosocial' => 9,
    'coordinador_supervision' => 10,
    'apoyo_supervision' => 11,
    'secretaria_cultural' => 12,
    'gestor' => 13,
    'monitor' => 14,
    'embajador' => 15,
    'instructor' => 16,
    'lider_embajador' => 17,
    'lider_instructor' => 18,
    'coordinador_seguimiento' => 19,
    'lider_metodologico' => 20,
    'coordinador_administrativo' => 21,

];
