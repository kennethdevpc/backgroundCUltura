import { roles } from "@/mixins";

export interface doubleManagement {
    first: roles,
    second: roles,
    three: roles,
}