type statuses = 'REC' | 'APRO' | 'REV' | 'ENREV' ;

export default statuses