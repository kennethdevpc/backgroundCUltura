export const scroll_top = () => {
    window.scrollTo(0, 0)
}