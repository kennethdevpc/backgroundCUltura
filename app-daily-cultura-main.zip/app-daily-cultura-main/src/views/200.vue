<script lang="ts" setup>
// Importing Overall librearies / Dependencies
</script>

<template>
    <div class="grid content-center justify-center h-screen">
      <h1 class="font-semibold text-9xl">200</h1>
      <h3 class="text-lg text-center">Componente de prueba</h3>
      <router-link class="text-center underline" to="/dashboard"
        >Ir al dashboard</router-link
      >
    </div>
  </template>
  