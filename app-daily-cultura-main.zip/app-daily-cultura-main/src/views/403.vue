<template>
  <div class="grid content-center justify-center h-screen">
    <h1 class="font-semibold text-9xl">403</h1>
    <h3 class="text-lg text-center">No tienes accesso</h3>
    <router-link class="text-center underline" to="/dashboard"
      >Ir al dashboard</router-link
    >
  </div>
</template>
